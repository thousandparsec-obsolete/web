
import os.path
import string, traceback
import sys
sys.path.append("../")

import netlib

def help(topic=""):
	"""\
	help [topic]

	Find out how to use a command.
"""
	if topic == "":
		help = "Possible commands:\n\n"

		for command in fmap.values():
			help += string.split(command.__doc__, "\n")[0] + "\n"

		self.pprint(help)
		return
		
	if globals().has_key(topic):
		self.pprint(globals()[topic].__doc__)


import cmd

class PyTextClient(cmd.Cmd):
	def __init__(self, completekey='tab', stdin=None, stdout=None):
		cmd.Cmd.__init__(self, completekey, stdin, stdout)

		# Clear the storage
		self.c=None
		self.o=None

		# Import the .pytextrc
		rc = os.path.expanduser("~")
		if rc != "~":
			file = os.path.join(rc, ".pytextrc")
			if os.path.exists(file):
				self.pprint("Found rc file: %s" % file)
				data = open(file, "r+").read()
				
				for line in string.split(data, "\n")[:-1]:
					self.pprint("Running line: %s" % line)
					
					self.onecmd(line)

		# Set the prompt
		self.promptset()
		
	def args(self, line, function):
		line = line.strip()
		if line == "":
			arguments = []
		else:
			arguments = string.split(line, " ")

		return apply(function, arguments)

	def emptyline(self):
		pass

	def postcmd(self, stop, line):
		self.promptset()

	def promptset(self):
		h = "None"
		if self.c != None:
			h = self.c.host
		u = "None"
		if self.c != None and hasattr(self.c, "username"):
			u = self.c.username
		o = "None"
		if self.o != None:
			o = self.o.name

		self.prompt = "%s@%s '%s' -> " % (u, h, o)

	def pprint(self, string):
		self.columnize([string])
		
	## Python Functions ########################
	def do_exec(self, line):
		"""\
exec *python_code_to_execute

Execute python code following the exec command.
Nothing will presist after the command executes.

For example,

-> exec print 2 + 2
4
-> exec a = []
-> exec print a
name 'a' is not defined
"""
		exec(line)
		
	def do_print(self, line):
		"""\
print object_to_print

Execute python code following the exec command. For example,

user@localhost 'The Universe' -> print 2 2
2
2
user@localhost 'The Universe' -> print self.o
<netlib.objects.ObjectExtra.Universe.Universe @ 0x4020fe0c>
"""
		for i in string.split(line):
			exec("print %s" % i)

	## Exit ####################################
	def do_exit(self, line):
		"""\
exit, quit

Leave the PyText-Client.
"""
		sys.exit(0)

	do_quit = do_exit

	## Connect #################################
	def do_connect(self, line):
		"""\
connect host [port]

Connect to a TP server on host, if port is not specified it
uses port 6329.
"""
		return self.args(line, self.connect)

	def connect(self, host, port=6923):
		self.pprint("Connecting to %s on %s ... \n" % (host, port))
		
		self.c = netlib.Connection(host, port, debug=1)
		if not self.c.connect():
			self.c = None
			self.pprint("Could not connect to the server. \n")
		else:
			self.o = None
			self.pprint("Connected. \n")

	def complete_connect(self, text, line, begidx, endidx):
		if text == "localhost"[:len(text)]:
			return ["localhost"]
		if text == "127.0.0.1"[:len(text)]:
			return ["127.0.0.1"]
		return []

	## Disconnect ##############################
	def do_disconnect(self, line):
		"""\
disconnect

Disconnect from the server.
"""
		return self.args(line, self.disconnect)

	def disconnect(self):
		if self.c == None:
			self.pprint("Not connected. \n")
			return

		self.c.disconnect()
		self.c = None
		self.pprint("Disconnected. \n")
		
	## Login ###################################
	def do_login(self, line):
		"""\
login username password

Login with a username and password.
"""
		return self.args(line, self.login)

	def login(self, username, password):
		if self.c == None:
			self.pprint("Not connected. \n")
			return

		if not self.c.login(username, password):
			self.pprint("Could not login. \n")
		else:
			self.pprint("Login OK. \n")

	## Object ##################################
	def do_object(self, line):
		"""\
object id

Enter into the object so you can select.
"""
		return self.args(line, self.object)
		
	def object(self, id):
		if self.c == None:
			self.pprint("Not connected. \n")
			return

		r = self.c.get_objects(int(id))
		if r:
			self.o = r[0]
		else:
			self.pprint("No such object. \n")
		
	## Show ####################################
	def do_show(self, line):
		"""\
show [name]

Displays the value of an attribute on an object.
"""
		return self.args(line, self.show)

	def show(self, name=""):
		if self.c == None:
			self.pprint("Not connected. \n")
			return
		if self.o == None:
			self.pprint("No object. \n")
			return

		if name == "":
			for name in self.o.__dict__.keys():
				self.show(name)
		elif name == "object":
			self.pprint("%s" % self.o)
		else:
			if hasattr(self.o, name):
				self.pprint("%s: %s \n" % (name, getattr(self.o, name)))
			else:
				self.pprint("No such attribute.")
	
	## Objects #################################
	def do_objects(self, line):
		"""\
objects

Lists the objects in the current object.
"""
		return self.args(line, self.objects)

	def objects(self, id):
		pass

	## Orders ##################################
	def do_orders(self, line):
		"""\
orders

Lists the orders in the current object.
"""
		return self.args(line, self.orders)

	def orders(self, *slots):
		slots = list(slots)
		for i in range(0, len(slots)):
			slots[i] = int(slots[i])
		
		if self.c == None:
			self.pprint("Not connected. \n")
			return
		if self.o == None:
			self.pprint("No object. \n")
			return

		print self.c.get_orders(self.o.id, slots)
		
	## Add Order ###############################
	def do_order_insert(self, line):
		"""\
order_add 

Lists the orders in the current object.
"""
		return self.args(line, self.order_insert)

	def order_insert(self, type, slot, *args):
		slot = int(slot)
		args = list(args)

		if type.lower() == 'nop':
			type = 0
			args[0] = int(args[0])
		elif type.lower() == 'move':
			type = 1
			args[0] = int(args[0])
			args[1] = int(args[1])
			args[2] = int(args[2])

		if self.c == None:
			self.pprint("Not connected. \n")
			return
		if self.o == None:
			self.pprint("No object. \n")
			return

		return apply(self.c.insert_order, (self.o.id, type, slot,) + tuple(args))

def main():
	m = PyTextClient()
	while True:
#		try:
			m.cmdloop()
#		except SystemExit, e:
#			break
#		except Exception, e:
#			print e
#			continue

if __name__ == "__main__":
	main()

