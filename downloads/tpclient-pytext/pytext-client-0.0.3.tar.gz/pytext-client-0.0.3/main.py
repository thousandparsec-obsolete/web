
import os.path
import string, traceback
import sys
sys.path.append("../")

import netlib
import cmd

from types import *

class PyTextClient(cmd.Cmd):
	def __init__(self, completekey='tab', stdin=None, stdout=None):
		cmd.Cmd.__init__(self, completekey, stdin, stdout)

		self.debug = 0

		# Clear the storage
		self.c=None
		self.o=None

		rc = os.path.expanduser("~")
		if rc != "~":
			# Import the .pytext_history
			file = os.path.join(rc, ".pytext_history")
			if os.path.exists(file):
				self.pprint("Found history file: %s" % file)
				data = open(file, "r+").read()
				
				self.history = string.split(data, "\n")[:-1]

				import readline
				for line in self.history:
					readline.add_history(line)
			else:
				self.history = []

			# Import the .pytextrc
			file = os.path.join(rc, ".pytextrc")
			if os.path.exists(file):
				self.pprint("Found rc file: %s" % file)
				data = open(file, "r+").read()
				
				for line in string.split(data, "\n")[:-1]:
					self.pprint("Running line: %s" % line)
					
					self.onecmd(line)

		# Set the prompt
		self.promptset()
	
	def postloop(self):
		rc = os.path.expanduser("~")
		if rc != "~":
			data = "\n".join(self.history)
			
			# Save the .pytext_history
			file = os.path.join(rc, ".pytext_history")
			print "Writing a history: %s" % file
			open(file, "w+").write(data)
			
		cmd.Cmd.postloop(self)

	def args(self, line, function):
		line = line.strip()
		if line == "":
			arguments = []
		else:
			arguments = string.split(line, " ")

		return apply(function, arguments)

	def postcmd(self, stop, line):
		self.promptset()

		if len(line.strip()) > 0:
			self.history.append(line.strip())

		return stop

	def promptset(self):
		h = "None"
		if self.c != None:
			h = self.c.host
		u = "None"
		if self.c != None and hasattr(self.c, "username"):
			u = self.c.username
		o = "None"
		if self.o != None:
			o = self.o.name

		self.prompt = "%s@%s '%s' -> " % (u, h, o)

	def pprint(self, string):
		self.columnize([string])
	

	## Default Functions #######################
	def emptyline(self):
		pass

	def complete_default(self, text, line, begidx, endidx):
		# Only do completion if there is something to match on
		r = []
	
		# Just look at the history (dont look back more then 100)
		for h in self.history[100::-1]:
			if h.startswith(line):
				if h == line:
					continue
				r.append(h[begidx:])

		return r

	completedefault = complete_default

	## Debug Functions #########################
	def do_debug(self, args):
		"""\
Toggle debug mode.
"""
		self.debug = not self.debug
		if self.c != None:
			self.c.debug = self.debug
		
	## History Functions #######################
	def do_history(self, args):
		"""\
Print a list of commands that have been entered.
"""
		for line in self.history:
			if args == "" or line.startswith(args):
				self.pprint(line)

	## Shell Functions #########################
	def do_shell(self, args):
		"""\
Pass command to a system shell.
"""
		os.system(args)

	## Python Functions ########################
	def do_exec(self, line):
		"""\
exec *python_code_to_execute

Execute python code following the exec command.
Nothing will presist after the command executes.

For example,

-> exec print 2 + 2
4
-> exec a = []
-> exec print a
name 'a' is not defined
"""
		exec(line)
		
	def do_print(self, line):
		"""\
print object_to_print

Execute python code following the exec command. For example,

user@localhost 'The Universe' -> print 2 2
2
2
user@localhost 'The Universe' -> print self.o
<netlib.objects.ObjectExtra.Universe.Universe @ 0x4020fe0c>
"""
		for i in string.split(line):
			exec("print %s" % i)

	def do_traceback(self, line):
		"""\
traceback

Print the traceback for the last error.
"""
		import traceback, pprint
		type, val, tb = sys.exc_info()
		self.pprint(string.join(traceback.format_exception(type, val, tb), ''))

	## Exit ####################################
	def do_exit(self, line):
		"""\
exit, quit

Leave the PyText-Client.
"""
		return -1

	do_quit = do_exit
	do_EOF = do_exit

	## Connect #################################
	def do_connect(self, line):
		"""\
connect host [port]

Connect to a TP server on host, if port is not specified it
uses port 6329.
"""
		return self.args(line, self.connect)

	def connect(self, host, port=6923):
		self.pprint("Connecting to %s on %s ... \n" % (host, port))
		
		self.c = netlib.Connection(host, port, debug=self.debug)
		if not self.c.connect():
			self.c = None
			self.o = None
			self.pprint("Could not connect to the server. \n")
		else:
			self.o = None
			self.pprint("Connected. \n")

	def complete_connect(self, text, line, begidx, endidx):
		if text == "localhost"[:len(text)]:
			return ["localhost"]
		if text == "127.0.0.1"[:len(text)]:
			return ["127.0.0.1"]
		return self.complete_default(text, line, begidx, endidx)

	## Disconnect ##############################
	def do_disconnect(self, line):
		"""\
disconnect

Disconnect from the server.
"""
		return self.args(line, self.disconnect)

	def disconnect(self):
		if self.c == None:
			self.pprint("Not connected. \n")
			return

		self.c.disconnect()
		self.c = None
		self.pprint("Disconnected. \n")
		
	## Login ###################################
	def do_login(self, line):
		"""\
login username password

Login with a username and password.
"""
		return self.args(line, self.login)

	def login(self, username, password):
		if self.c == None:
			self.pprint("Not connected. \n")
			return

		if not self.c.login(username, password):
			self.pprint("Could not login. \n")
		else:
			self.pprint("Login OK. \n")

	## Object ##################################
	def do_object(self, line):
		"""\
object id

Enter into the object so you can select.
"""
		return self.args(line, self.object)
		
	def object(self, id):
		if self.c == None:
			self.pprint("Not connected. \n")
			return

		r = self.c.get_objects(int(id))
		if r[0] and type(r[0]) != TupleType:
			self.o = r[0]
		else:
			self.pprint("No such object. \n")
		
	## Show ####################################
	def do_show(self, line):
		"""\
show [name]

Displays the value of an attribute on an object.
"""
		return self.args(line, self.show)

	def show(self, name=""):
		if self.c == None:
			self.pprint("Not connected. \n")
			return
		if self.o == None:
			self.pprint("No object. \n")
			return

		if name == "":
			for name in self.o.__dict__.keys():
				self.show(name)
		elif name == "object":
			self.pprint("%s" % self.o)
		else:
			if hasattr(self.o, name):
				self.pprint("%s: %s \n" % (name, getattr(self.o, name)))
			else:
				self.pprint("No such attribute.")
	
	## Objects #################################
	def do_objects(self, line):
		"""\
objects

Lists the objects in the current object.
"""
		return self.args(line, self.objects)

	def objects(self, id):
		pass

	## Orders ##################################
	def do_orders(self, line):
		"""\
orders [slot]

Lists the orders in the current object.
"""
		return self.args(line, self.orders)

	def orders(self, *slots):
		slots = list(slots)
		for i in range(0, len(slots)):
			slots[i] = int(slots[i])
		
		if len(slots) == 0:
			slots = range(0, self.o.order_number)
		
		if self.c == None:
			self.pprint("Not connected. \n")
			return
		if self.o == None:
			self.pprint("No object. \n")
			return

		r = self.c.get_orders(self.o.id, slots)
		if type(r) == ListType:
			for i in r:
				self.pprint(str(i))
		else:
			self.pprint(str(r))
		
	def do_order_remove(self, line):
		"""\
order_remove [slot]

Remove an order from the current current object.
"""
		return self.args(line, self.order_remove)

	def order_remove(self, *slots):
		slots = list(slots)
		for i in range(0, len(slots)):
			slots[i] = int(slots[i])
		
		if len(slots) == 0:
			slots = range(0, self.o.order_number)
		
		if self.c == None:
			self.pprint("Not connected. \n")
			return
		if self.o == None:
			self.pprint("No object. \n")
			return

		r = self.c.remove_orders(self.o.id, slots)
		if type(r) == ListType:
			for i in r:
				self.pprint(str(i))
		else:
			self.pprint(str(r))

	## Add Order ###############################
	def do_order_insert(self, line):
		"""\
order_add 

Lists the orders in the current object.
"""
		return self.args(line, self.order_insert)

	def order_insert(self, slot, type, *args):
		slot = int(slot)
		args = list(args)

		if type.lower() == 'nop':
			type = 0
			args[0] = int(args[0])
		elif type.lower() == 'move':
			type = 1
			args[0] = int(args[0])
			args[1] = int(args[1])
			args[2] = int(args[2])

		if self.c == None:
			self.pprint("Not connected. \n")
			return
		if self.o == None:
			self.pprint("No object. \n")
			return

		self.pprint(str(apply(self.c.insert_order, (self.o.id, slot, type,) + tuple(args))))

	## Time Stuff ##############################
	def do_time(self, line):
		"""\
order_add 

Lists the orders in the current object.
"""
		return self.args(line, self.time)

	def time(self):
		if self.c == None:
			self.pprint("Not connected. \n")
			return

		r = self.c.time()
		if r[0]:
			sh = 60*60
			sm = 60
			
			hour = int(r[1]/sh)
			min = int((r[1]-hour*sh)/sm)
			sec = r[1]-hour*sh-min*sm

			self.pprint("Turn ends: %i hours %i min %i seconds." % (hour, min, sec))
		else:
			self.pprint("Turn has ended.")


def main():
	m = PyTextClient()
	while True:
		try:
			m.cmdloop()
		except SystemExit, e:
			break
		except Exception, e:
			type, val, tb = sys.exc_info()
			print ''.join(traceback.format_exception(type, val, tb))
			continue
		else:
			return

if __name__ == "__main__":
	main()

