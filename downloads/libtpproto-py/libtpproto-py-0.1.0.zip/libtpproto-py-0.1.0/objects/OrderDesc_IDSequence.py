from Base import IDSequence

class OrderDesc_IDSequence(IDSequence):
	"""\
	"""
	no = 33

