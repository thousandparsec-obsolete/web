from Base import GetIDSequence

class OrderDesc_GetID(GetIDSequence):
	"""\
	"""
	no = 32

