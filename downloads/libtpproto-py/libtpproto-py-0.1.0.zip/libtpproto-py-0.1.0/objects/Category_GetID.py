from Base import GetIDSequence

class Category_GetID(GetIDSequence):
	"""\
	"""
	no = 45

