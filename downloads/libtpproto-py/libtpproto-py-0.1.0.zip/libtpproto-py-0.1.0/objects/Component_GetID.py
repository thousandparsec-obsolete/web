from Base import GetIDSequence

class Component_GetID(GetIDSequence):
	"""\
	"""
	no = 56

