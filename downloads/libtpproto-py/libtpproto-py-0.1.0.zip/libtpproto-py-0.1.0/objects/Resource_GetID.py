from Base import GetIDSequence

class Resource_GetID(GetIDSequence):
	"""\
	"""
	no = 37

