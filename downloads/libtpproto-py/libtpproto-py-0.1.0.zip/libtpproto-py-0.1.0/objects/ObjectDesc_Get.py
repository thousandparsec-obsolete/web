from Base import GetWithID

class Object_DescGet(GetWithID):
	"""\
	"""
	no = -1

