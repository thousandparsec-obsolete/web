from Base import GetIDSequence

class Property_GetID(GetIDSequence):
	"""\
	"""
	no = 60

