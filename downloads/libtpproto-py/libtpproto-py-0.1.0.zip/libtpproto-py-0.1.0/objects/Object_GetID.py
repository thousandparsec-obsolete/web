from Base import GetIDSequence

class Object_GetID(GetIDSequence):
	"""\
	"""
	no = 28

