from Base import GetIDSequence

class Board_GetID(GetIDSequence):
	"""\
	"""
	no = 35

