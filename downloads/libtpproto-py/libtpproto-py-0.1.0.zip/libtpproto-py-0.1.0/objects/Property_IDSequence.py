from Base import IDSequence

class Property_IDSequence(IDSequence):
	"""\
	"""
	no = 61

