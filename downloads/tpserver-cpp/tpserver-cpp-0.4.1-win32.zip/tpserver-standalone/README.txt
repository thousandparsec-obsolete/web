tpserver 0.4.1 for Windows
-------------------------------------------------------------
This is a version of the C++ Thousand Parsec server compiled 
for windows. The server is standalone and does not need 
anything to be install.

It is compiled with support for:
 - MiniSec
 - Guile

No persistance support is enabled.

Running
-------------------------------------------------------------
To run just double click on the "tpserver-cpp.bat" file.

Configuring
-------------------------------------------------------------
To change the configuration just edit the tpserver-cpp.conf
The default configuration file should be fine.

License
-------------------------------------------------------------
The code is released under the GPL. You can get your full 
copy of the source code from http://www.thousandparsec.net/

You can get a full text of the license from 
 http://www.gnu.org/copyleft/gpl.html