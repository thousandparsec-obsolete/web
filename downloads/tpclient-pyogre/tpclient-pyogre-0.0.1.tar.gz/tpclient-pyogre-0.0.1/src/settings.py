icon_zoom_switch_level = 0.5
show_stars_during_icon_view = False
zoom_speed = 1
distance_units = 25000
show_fps = False
show_intro = True

user_name = None
password = None
save_details = False
previous_game = None

# default sound settings
sound_effects = True
music = True

# runtime objects, for configuration purposes
renderers = None
render_window = None
render_system = None
sound_devices = []
current_sound_device = ""
sound_support = False
