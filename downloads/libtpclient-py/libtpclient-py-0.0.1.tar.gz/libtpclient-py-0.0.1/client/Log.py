"""\
A Log is a version of the Cache which can have changes which happen undone and previous versions can be viewed.
"""
