from Base import IDSequence

class Object_IDSequence(IDSequence):
	"""\
	"""
	no = 31

