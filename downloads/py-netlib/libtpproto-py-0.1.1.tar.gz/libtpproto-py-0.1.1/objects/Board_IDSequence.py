from Base import IDSequence

class Board_IDSequence(IDSequence):
	"""\
	"""
	no = 36

