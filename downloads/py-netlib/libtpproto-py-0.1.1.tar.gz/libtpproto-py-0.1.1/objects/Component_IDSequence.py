from Base import IDSequence

class Component_IDSequence(IDSequence):
	"""\
	"""
	no = 57

