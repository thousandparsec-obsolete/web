from Base import GetWithID

class Object_GetID_ByContainer(GetWithID):
	no = 30

