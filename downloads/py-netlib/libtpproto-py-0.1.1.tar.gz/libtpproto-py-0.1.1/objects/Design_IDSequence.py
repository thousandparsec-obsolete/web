from Base import IDSequence

class Design_IDSequence(IDSequence):
	"""\
	"""
	no = 53

