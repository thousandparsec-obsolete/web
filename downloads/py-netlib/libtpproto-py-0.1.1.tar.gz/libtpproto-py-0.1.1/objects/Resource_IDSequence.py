from Base import IDSequence

class Resource_IDSequence(IDSequence):
	"""\
	"""
	no = 38

