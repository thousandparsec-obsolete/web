from Base import IDSequence

class Category_IDSequence(IDSequence):
	"""\
	"""
	no = 46

