
host = "127.0.0.1"
port = ""


# Connect to the server


# Send trash


mapping[Connect] =


mapping[OK] = OK
mapping[Fail] = Fail
mapping[Connect] = Connect
mapping[Login] = Login
mapping[Object_Get] = Object_Get
mapping[Object] = Object
mapping[Object_GetByPos] = Object_GetByPos
mapping[Object_ListSequence] = Object_ListSequence


