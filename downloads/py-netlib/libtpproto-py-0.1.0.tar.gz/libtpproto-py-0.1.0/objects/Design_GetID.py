from Base import GetIDSequence

class Design_GetID(GetIDSequence):
	"""\
	"""
	no = 52

