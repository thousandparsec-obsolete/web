from Get import Get

class OrderDesc_Get(Get):
	"""\
	The Object_Get packet consists of:
		* A UInt32, ID of object to get.
	"""
	no = 8

