from Get import Get

class Object_DescGet(Get):
	"""\
	"""
	no = -1

