
version = (0, 0, 5)

import sys
from os import path
sys.path.insert(0, path.dirname(__file__))

from connection import Connection
Connection = Connection

