#! /usr/bin/env python

# Version check
try:
	import wxPython
	import string
	
	version = string.split(wxPython.__version__, '.')
	intversion = int(version[0])*1000000+int(version[1])*10000+int(version[2])*100

except ImportError:
	intversion = 0

if intversion < 2050000:
	print "Your version of wxPython is too old. You will not be able to run pywx-client."
	print "You have version", intversion
	print "You need version atleast", [2, 5, 0, 0]
	import sys
	sys.exit(1)
else:
	del wxPython
	del string

import sys

import gettext
gettext.install("pywx-client")

# wx.Python imports
import wx
import extra
import extra.fixdc

# Python Imports
import time
from math import *
from copy import *
from types import *

import string
import pprint
import thread

try:
	import tp.netlib
except ImportError:
	import sys
	sys.path.append("..")
	import tp.netlib

from utils import *
from tp.netlib import Connection, failed

from windows.control import MainControl

class Splash(wx.SplashScreen):
	def __init__(self, application):
		image = wx.Image("graphics/splash.png").ConvertToBitmap()
		wx.SplashScreen.__init__(self, image, wx.SPLASH_CENTRE_ON_SCREEN | wx.SPLASH_TIMEOUT, 3000, None, -1)

		self.application = application
		
		self.Bind(wx.EVT_CLOSE, self.OnClose)

	def OnClose(self, evt):
		self.Hide()
		time.sleep(1)
		self.application.windows.connect.Show(True)

class AppTP(wx.App):
	def __init__(self):
		wx.App.__init__(self)

		if wx.Platform in ('__WXMSW__', '__WXMAC__'):
			class Null(object):
				def write(self, *args, **kw):
					pass
				def flush(self, *args, **kw):
					pass
			sys.stdout = Null()

		try:
			wx.InitAllImageHandlers()
			self.config = self.ConfigLoad()
			self.windows = MainControl(self)
			self.connection = Connection()
			splash = Splash(self)
			splash.Show()

		except:
			do_traceback()

	def ConfigLoad(self):
		pass

	def ConfigSave(self):
		pass

	def CacheLoad(self):
		pass

	def CacheSave(self):
		pass

	def CacheUpdate(self):
		progress = wx.ProgressDialog("TP: Downloading Universe", "pywx-client is now downloading the Universe.", \
			100, self.windows.connect, wx.PD_APP_MODAL | wx.PD_AUTO_HIDE | wx.PD_ELAPSED_TIME | wx.PD_REMAINING_TIME)

		class Blank:
			pass
		
		self.cache = Blank()
		self.cache.objects = {}
		self.cache.orders = {}
		self.cache.boards = {}
		self.cache.messages = {}

		# Download objects
		objects = self.connection.get_objects(0)
		while len(objects) > 0:
			object = objects.pop(0)
			
			if failed(object):
				print object
				continue
			
			self.cache.objects[object.id] = object
			
			# Download the objects inside this object
			if len(object.contains) > 0:
				# Set the parent relationship
				nobjects = self.connection.get_objects(object.contains)
				for nobject in nobjects:
					if failed(nobject):
						print nobject
						continue
					else:
						nobject.parent = object.id
					objects.append(nobject)

			# Download the orders from this object
			self.cache.orders[object.id] = []
			if object.order_number != 0:
				for order in self.connection.get_orders(object.id, range(0, object.order_number)):
					if failed(order):
						break
					self.cache.orders[object.id].append(order)

			progress.Update(len(self.cache.objects.keys()))

		# Download any order descriptions not already downloaded
		descs = []
		while True:
			r = self.connection.get_orderdescs(len(descs))[0]
			if not failed(r):
				descs.append(r)
				descs[-1].register()
			else:
				break

		# Download message boards
		board = self.connection.get_boards(0)[0]
		if not failed(board):
			print "Downloading messages for the board", board.id, board.number
			# Download the messages from this board
			if board.number == 0:
				messages = []
			elif board.number == 1:
				messages = self.connection.get_messages(board.id, range(0, board.number))
				if not hasattr(messages, "__getitem__"):
					messages = [messages]
				else:
					messages = list(messages)
			else:
				messages = self.connection.get_messages(board.id, range(0, board.number))
			self.cache.messages[board.id] = list(messages)
		else:
			self.cache.messages[0] = []

		progress.Update(100)
		self.windows.Post(wx.local.CacheUpdateEvent())

		# Get the time remaining
		seconds = self.connection.time()
		print seconds
		if not failed(seconds):
			import time
			self.windows.main.statusbar.SetEndTime(time.time() + seconds[1] - 5)

	def Exit(self):
		print "AppTp.exit"
		sys.exit(1)

if __name__ == '__main__':
	try:
		app = AppTP()
		app.MainLoop()
	finally:
		do_traceback()
		sys.stdin.read(1)
	
