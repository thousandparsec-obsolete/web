#! /usr/bin/env python

import requirements
import sys

# wx.Python imports
import wx
import extra

# Python Imports
import pprint
import socket
import time
import threading
from types import *

# Local imports
import utils
from utils import debug, DEBUG_MAIN, DEBUG_GUI, DEBUG_NETWORK
from tp.netlib import Connection, failed, constants

def make(thread, method):
	def t(*args, **kw):
		thread.Call(method, *args, **kw)
	return t

class Cache(object):
	"""\
	This is the a cache of the data downloaded from the network. 
	
	It can be pickled and restored at a later date to preserve the data accross application runs.
	"""

	class CacheEvent(object):
		"""\
		Raised when the game cache is made dirty. Contains a reference to what was updated.
		"""
		def __init__(self, what, action, id, *args, **kw):
			if what in Cache.readonly:
				raise ValueError("Can not change that!")
			elif not what in Cache.readwrite:
				raise ValueError("Invalid value (%s) for what" % (what,))
			else:
				self.what = what

			if not action in Cache.actions:
				raise ValueError("Invalid action (%s)" % (action,))
			else:
				self.action = action

			self.id = id

			args = list(args)	
			if what in Cache.compound:
				if len(args) == 2:
					self.slot = args.pop(0)
				elif kw.has_key('slot'):
					self.slot = kw['slot']
				else:
					raise TypeError("A slot value is required for compound types.")
			
			if len(args) == 1:
				self.change = args.pop(0)
			elif kw.has_key('change'):
				self.change = kw['change']
			else:
				raise TypeError("The actual change needs to be added.")

		def __str__(self):
			if not self.what:
				return "<%s full-update>" % (self.__class__,)
			elif hasattr(self, 'slot'):
				return "<%s %s %s id=%i slot=%i>" % (self.__class__, self.what, self.action, self.id, self.slot)
			else:
				return "<%s %s %s id=%i>" % (self.__class__, self.what, self.action, self.id)
		
	class CacheDirtyEvent(CacheEvent):
		"""\
		Raised when the game cache is made dirty. Contains a reference to what was updated.
		"""
		pass

	class CacheUpdateEvent(CacheEvent):
		"""\
		Raised when the game cache is changed. Contains a reference to what was updated. 
		If the what is None a new cache has been created.
		"""
		def __init__(self, what, *args, **kw):
			if what == None:
				self.what = None
			else:
				CacheEvent.__init__(self, what, *args, **kw)

	readonly = ("features", "objects", "orders_probe", "boards", "resources", "components", "properties", "players", "resources")
	readwrite = ("orders", "messages", "categories", "designs")
	actions = ("create", "remove", "change")
	compound = ("orders", "messages")
	
	def __init__(self):
		class ChangeDict(dict):
			"""\
			A simple dictionary which also stores the "times" an object was last updated.

			Used so that we only upload/download items which have changed.
			"""
			def __init__(self):
				dict.__init__(self)
				self.times = {}
			
			def __setitem__(self, key, value):
				"""\
				This set item is special, it only takes keys of the form,
				(<last modified time>, <normal key>)
				"""
				if type(value) is TupleType and len(value) == 2:
					self.times[key] = value[0]
					value = value[1]
				else:
					self.times[key] = -1
				dict.__setitem__(self, key, value)
		
			def __delitem__(self, key):
				del self.times[key]
				dict.__delitem__(self, key)

		# Features
		self.features		= []

		# The object stuff
		self.objects		= ChangeDict()
		self.orders			= ChangeDict()
		self.orders_probe	= ChangeDict()

		# The message boards
		self.boards			= ChangeDict()
		self.messages		= ChangeDict()

		# Design stuff
		self.categories		= ChangeDict()
		self.designs		= ChangeDict()
		self.components		= ChangeDict()
		self.properties		= ChangeDict()

		self.players		= ChangeDict()
		self.resources		= ChangeDict()

	def apply(self, evt):
		if not isinstance(evt, self.CacheDirtyEvent):
			raise TypeError("I can only accept CacheDirtyEvents")
		
		if not evt.what in Cache.compound:
			if evt.action == "create" or evt.action == "change":
				getattr(self, evt.what)[evt.id] = (-1, evt.change)
			elif evt.action == "remove":
				del getattr(self, evt.what)[evt.id]
		else:
			d = getattr(self, evt.what)[evt.id]
			if evt.action == "create":
				if evt.slot == -1:
					d.append(evt.change)
				else:
					d.insert(evt.slot, evt.change)
					
			elif evt.action == "change":
				d[evt.slot] = evt.change
			elif evt.action == "remove":
				del d[evt.slot]

		evt.__class__ = self.CacheUpdateEvent

class Application(object):
	"""
	Container for all the applications threads and the network cache.

	Calling accross threads requires you to use the .Call method on each thread - DO NOT call directly!
	The cache can be accessed by either thread at any time - be careful.
	"""
	
	def __init__(self):
		self.gui = GUI(self)
		self.network = Network(self)

		self.cache = Cache()
		
		# Load the Configuration
		self.ConfigLoad()

	def Run(self):
		"""\
		Set the application running.
		"""
		self.init = True

		self.gui.start()
		self.network.start()

	def ConfigDisplay(self):
		"""\
		Pop-up the configuration window.
		"""
		self.gui.ConfigDisplay()

	def ConfigSave(self):
		"""\
		"""
		# FIXME: This should be fixed, utils needs to go away
		config = self.gui.ConfigSave()
		utils.save_data("pywx_preferences", config)
		
		debug(DEBUG_MAIN, "Saving the config...\n" + pprint.pformat(config))

	def ConfigLoad(self):
		"""\
		"""
		config = utils.load_data("pywx_preferences")
		if config is None:
			config = {}
	
		debug(DEBUG_MAIN, "Loading the config...\n" + pprint.pformat(config))
		
		self.gui.ConfigLoad(config)

	def Post(self, event):
		"""\
		Post an application wide event to every thread.
		"""
		self.gui.Call(self.gui.Post, event)
		self.network.Call(self.network.Post, event)

	def Exit(self):
		"""
		Exit the program.
		"""
		self.gui.Call(self.gui.Cleanup)
		self.network.Call(self.network.Cleanup)

class GUI(wx.App, threading.Thread):
	## These are window events
	class ShowWindowEvent(wx.PyEvent):
		"""\
		Raised when the the windows are showed.
		"""
		pass

	class SelectObjectEvent(wx.PyEvent):
		"""\
		Raised when an object is selected.
		"""
		def __init__(self, id):
			self.id = id
	
		def __str__(self):
			return "<SelectObjectEvent id=%s>" % self.id
	
	class SelectPositionEvent(wx.PyEvent):
		"""\
		Raised when a position is selected.
		"""
		def __init__(self, pos):
			self.x, self.y, self.z = pos
		
		def __str__(self):
			return "<SelectPositionEvent (%s, %s %s)>" % (self.x, self.y, self.z)
	
	class SelectOrderEvent(wx.PyEvent):
		"""\
		Raised when an order is selected.
		"""
		def __init__(self, id, slots):
			self.id = id
			self.slots = slots
		
		def __str__(self):
			return "<SelectOrderEvent id=%s slots=%s>" % (self.id, self.slots)

	class DirtyOrderEvent(wx.PyEvent):
		"""\
		Raised when an order is selected.
		"""
		def __init__(self, order):
			self.id = order.id
			self.slot = order.slot
			self.order = order
		
		def __str__(self):
			return "<SelectOrderEvent id=%s slots=%s>" % (self.id, self.slots)

	######################################

	def __init__(self, application):
		threading.Thread.__init__(self)
		wx.App.__init__(self)
		
		self.application = application
		self.exit = False

		self.current = None

		# Don't want to show the stdin/stdout stuff
		if wx.Platform in ('__WXMSW__', '__WXMAC__'):
			class Null(object):
				def write(self, *args, **kw):
					pass
				def flush(self, *args, **kw):
					pass
			sys.stdout = Null()

		try:
			wx.InitAllImageHandlers()
			
			# Show the splash screen
			from windows.winSplash import winSplash
			self.splash = winSplash(application)
			self.Show(self.splash)
			
			# Load the other main windows
			from windows.winMain import winMain
			self.main = winMain(application)

			from windows.winConnect import winConnect
			self.connectto = winConnect(application)

			from windows.winUpdate import winUpdate
			self.update = winUpdate(application)

			from windows.winDebug import winDebug
			self.debug = winDebug(application)
		
			self.windows = (self.main, self.connectto, self.update, self.debug)
		
			from windows.winConfig import winConfig
			self.config = winConfig(application, self.windows)

		except:
			utils.do_traceback()

	def run(self):
		self.MainLoop()

	def Cleanup(self):
		for window in self.windows:
			window.Close()
		while self.application.network.isAlive():
			time.sleep(0.1)
		sys.exit()

	# Config Functions ------------------------------------------------
	def ConfigDisplay(self):
		"""\
		Display the configuration window.
		"""
		self.config.Show(True)

	def ConfigSave(self):
		"""\
		Display the configuration window.
		"""
		config = {}
		for window in self.windows:
			config[window.title] = window.ConfigSave()
		return config

	def ConfigLoad(self, config):
		"""\
		Display the configuration window.
		"""
		for window in self.windows:
			window.ConfigLoad(config.get(window.title, {}))

	# Inter-Thread Functions ------------------------------------------------
	def Call(self, method, *args, **kw):
		"""\
		Call a method in this thread.
		"""
		wx.CallAfter(method, *args, **kw)

	def Post(self, event):
		"""
		Post an Event the current window.
		"""
		func = 'On' + event.__class__.__name__[:-5]
		#debug(DEBUG_GUI, "Posting %s to %s" % (event, func))
		if hasattr(self, func):
			getattr(self, func)(event)

		self.current.Post(event)

	def Show(self, window):
		"""
		Change to a certain main window.
		"""
		if window == self.current:
			return

		if self.current != None:
			self.current.Hide()

		self.current = window
		r = self.current.Show()

		self.Post(self.ShowWindowEvent())
		return r

	# Event Handlers ------------------------------------------------
	def OnNetworkFailure(self, evt):
		self.Show(self.connectto)

		# When the network fails pop-up a dialog then go to the connectto screen
		dlg = wx.MessageDialog(self.current, str(evt), _("Network Error"), wx.OK|wx.ICON_ERROR)
		dlg.ShowModal()
		dlg.Destroy()

class Network(threading.Thread):

	## These are network events
	class NetworkFailureEvent(Exception):
		"""\
		Raised when the network connection fails for what ever reason.
		"""
		pass

	######################################

	def __init__(self, application):
		threading.Thread.__init__(self)
		self.application = application
		self.exit = False

		self.tocall = []
		self.connection = Connection()
	
	def run(self):
		while not self.exit:
			if len(self.tocall) <= 0:
				if hasattr(time, 'sleep'):
					time.sleep(0.1)
				continue
			
			method, args, kw = self.tocall.pop(0)
			try:
				method(*args, **kw)
			except (IOError, socket.error), e:
				s  = _("There was an unknown network error.\n")
				s += _("Any changes since last save have been lost.\n")
				if getattr(self.connection, 'debug', False):
					s += _("A traceback of the error was printed to the console.\n")
					do_traceback()
				self.application.Post(self.NetworkFailureEvent(s))

	def Cleanup(self):
		self.exit = True

	def Call(self, method, *args, **kw):
		"""\
		Call a method in this thread.
		"""
		self.tocall.append((method, args, kw))

	def Post(self, event):
		"""
		Post an Event the current window.
		"""
		func = 'On' + event.__class__.__name__[:-5]
		debug(DEBUG_NETWORK, "Posting %s to %s" % (event, func))
		if hasattr(self, func):
			getattr(self, func)(event)

	def ConnectTo(self, host, port, username, password, debug=False):
		"""\
		Connect to a given host using a certain username and password.
		"""
		# FIXME: This should be sending events really
		gui = self.application.gui
		up = make(gui, gui.update.Update)
	
		# Show the Update window
		gui.Call(gui.Show, gui.update)
		
		up("Connecting...", mode="connecting")
		if self.connection.setup(host=host, port=port, debug=debug):
			s  = _("The client was unable to connect to the host.\n")
			s += _("This could be because the server is down or there is a problem with the network.\n")
			self.application.Post(self.NetworkFailureEvent(s))
			return
			
		up("Looking for Thousand Parsec Server...")
		if failed(self.connection.connect()):
			s  = _("The client connected to the host but it did not appear to be a Thousand Parsec server.\n")
			s += _("This could be because the server is down or the connection details are incorrect.\n")
			self.application.Post(self.NetworkFailureEvent(s))
			return

		up("Logining In")
		if failed(self.connection.login(username, password)):
			s  = _("The client connected to the host but could not login because the username of password was incorrect.\n")
			s += _("This could be because you are connecting to the wrong server or mistyped the username or password.\n")
			self.application.Post(self.NetworkFailureEvent(s))
			return

		self.CacheUpdate()

	def CacheUpdate(self):
		gui = self.application.gui
		up = make(gui, gui.update.Update)

		# Show the update window
		gui.Call(gui.Show, gui.update)
		
		# Create the cache
		cache = Cache()

		# Get the features this server support
		up("Looking for supported features...", mode="connecting")
		cache.features = self.connection.features()
		debug(DEBUG_NETWORK, "Features:", cache.features)
	
		# Boards and objects are special cases in which we have a sub-object to get
	
		# Get all the objects
		# -----------------------------------------------------------------------------------
		up("Getting objects...", mode="objects")
		iter = self.connection.get_object_ids(iter=True)
		
		for id, time in iter:
			up("Getting object with id of %i (last modified at %s)..." % (id, time), of=iter.total)

			if not cache.objects.has_key(id) or time > cache.objects.times[id]:
				object = self.connection.get_objects(id=id)[0]
			
				# Did we download the object okay?
				if failed(object):
					# Clean up the object
					if cache.objects.has_key(id):
						del cache.objects[id]

						if cache.orders.has_key(id):
							del cache.orders[id]
					continue

				cache.objects[id] = (time, object)

				# Download the orders from this object
				cache.orders[id] = []
				for order in self.connection.get_orders(id, range(0, object.order_number)):
					if failed(order):
						break
					cache.orders[id].append(order)

			elif constants.FEATURE_ORDERED_OBJECT in cache.features:
				up("Skipping remaining as already cached!")
				break
			
			up("Got object with id of %i (last modified at %s)..." % (id, time), add=1)

		print "Objects ["
		for id,o in cache.objects.items():
			print " %s : %s ," % (id, o),
		print "]"

		print "Building two way Universe Tree for speed"
		def build(object, parent=None, cache=cache):
			if parent:
				object.parent = parent.id
			for id in object.contains:
				build(cache.objects[id], object)
		build(cache.objects[0])

		# Get all the boards 
		# -----------------------------------------------------------------------------------
		up("Getting boards...", mode="boards")
		iter = self.connection.get_board_ids(iter=True)
		
		for id, time in iter:
			up("Getting board with id of %i (last modified at %s)..." % (id, time), of=iter.total)

			if not cache.boards.has_key(id) or time > cache.boards.times[id]:
				board = self.connection.get_boards(id=id)[0]

				# Did we download the board okay?
				if failed(board):
					# Clean up the board
					if cache.boards.has_key(id):
						del cache.boards[id]

						if cache.messages.has_key(id):
							del cache.messages[id]
					continue

				cache.boards[id] = (time, board)

				# Download the orders from this object
				cache.messages[id] = []
				for message in self.connection.get_messages(id, range(0, board.number)):
					if failed(message):
						break
					cache.messages[id].append(message)

			elif constants.FEATURE_ORDERED_BOARD in cache.features:
				up("Skipping remaining as already cached!")
				break
				
			up("Got board with id of %i (last modified at %s)..." % (id, time), add=1)

		print "Boards ["
		for id,o in cache.boards.items():
			print " %s : %s ," % (id, o)
		print "]"

		# Get all the order descriptions
		# -----------------------------------------------------------------------------------
		up("Getting order descriptions...", mode="order_descs")
		iter = self.connection.get_orderdesc_ids(iter=True)
		
		for id, time in iter:
			up("Getting board with id of %i (last modified at %s)..." % (id, time), of=iter.total)

			desc = self.connection.get_orderdescs(id=id)[0]

			# Did we download the board okay?
			if not failed(desc):
				desc.register()
			else:
				print "Warning: failed to get %i" % id, desc
		
			up("Got order description with id of %i (last modified at %s)..." % (id, time), add=1)

		def get_all(name, get_ids, get, cache, feature, up=up):

			up("Getting %s..." % name, of=0)
			iter = get_ids(iter=True)
			
			for id, time in iter:
				up("Getting %s with id of %i (last modified at %s)..." % (name, id, time), of=iter.total)

				if not cache.has_key(id) or time > cache.times[id]:
					frame = get(id=id)[0]

					# Did we download the board okay?
					if failed(frame):
						print "Failed to get %i removing" % id
						if cache.has_key(id):
							del cache[id]
						continue

					cache[id] = (time, frame)

				elif feature in cache.features:
					up("Skipping remaining as already cached!")
					break
				
				up("Got %s with id of %i (last modified at %s)..." % (name, id, time), add=1)

			print name, "[",
			for object in cache.values():
				print " <'%s' %i>" % (object.name, object.id)
			print "]"

		up("Getting design objects...", mode="designs")
		get_all("Categories", self.connection.get_category_ids, self.connection.get_categories, 
					cache.categories, constants.FEATURE_ORDERED_CATEGORY)

		get_all("Designs", self.connection.get_design_ids, self.connection.get_designs, 
					cache.designs, constants.FEATURE_ORDERED_DESIGN)
					
		get_all("Components", self.connection.get_component_ids, self.connection.get_components, 
					cache.components, constants.FEATURE_ORDERED_COMPONENT)
		
		get_all("Properties", self.connection.get_property_ids, self.connection.get_properties, 
					cache.properties, constants.FEATURE_ORDERED_PROPERTY)
				
		up("Getting all other objects...", mode="remaining")
		get_all("Resources", self.connection.get_resource_ids, self.connection.get_resources, 
					cache.resources, constants.FEATURE_ORDERED_RESOURCE)

		gui.Call(gui.Show, gui.main)

		# Update the cache
		self.application.cache = cache
		self.application.Post(self.application.cache.CacheUpdateEvent(None))
		return

	def OnCacheDirty(self, evt):
		"""\
		When the cache gets dirty we have to push the changes to the server.
		"""
		try:
			if evt.what == "orders":
				if evt.action in ("remove", "change"):
					if failed(self.connection.remove_orders(evt.id, evt.slot)):
						raise IOError("Unable to remove the order...")
				
				if evt.action in ("create", "change"):
					if failed(self.connection.insert_order(evt.id, evt.slot, evt.change)):
						raise IOError("Unable to insert the order...")

					if evt.slot == -1:
						evt.slot = len(self.application.cache.orders[evt.id])
						
					o = self.connection.get_orders(evt.id, evt.slot)[0]
					if failed(o):
						raise IOError("Unable to get the order..." + o[1])

					evt.change = o
			elif evt.what == "messages" and evt.action == "remove":
				if failed(self.connection.remove_messages(evt.id, evt.slot)):
					raise IOError("Unable to remove the order...")
			else:
				raise ValueError("Can't deal with that yet!")
			self.application.cache.apply(evt)
			self.application.Post(evt)

		except Exception, e:
			utils.do_traceback()
			self.application.Post(self.NetworkFailureEvent(e))
			"There where the following errors when trying to send changes to the server:"
			"The following updates could not be made:"


if __name__ == '__main__':
	try:
		app = Application()
		app.Run()
	finally:
		utils.do_traceback()
