
# wxPython imports
from wxPython.wx import *

# Python Imports
from math import *
from copy import *

import string
import pprint

# setup the path for the common stuff
import sys
sys.path.append("..")

from network import protocol
from utils import *

from UserDict import UserDict
class NameMap(UserDict):
	def __init__(self, dict=None):
		self.data = {}
		if dict is not None:
			self.update(dict)

	def saveconfig(self, file, overwrite=1):
		if os.path.exists(file) and overwrite:
			os.remove(file)
		elif os.path.exists(file):
			raise IOError, "Mapping file (%s) already exists" % file
		
		f = open(file, 'w+')
		for ID in self.data.keys():
			f.write("%s %s\n" % (str(ID), self.data[i]) )

	def loadconfig(self, file):
		if not os.path.exists(file):
			raise IOError, "Mapping file (%s) doesn't exist" % file
		f = open(file)
		input = f.read()
		for line in string.split(input, '\n'):
			key = string.split(line[0])[0]
			self.data[key] = line[len(key):]

	def getName(self, name):
		if name in self.data.items():
			for i in self.data.keys():
				if self.data[i] == name:
					return i
		else:
			raise KeyError, "No such name in this mapping"

if __name__ == '__main__':

	class mainControl:
		def __init__(self, app):

			self.app = app

			##########
			# Load the windows
			##########
			from windows.winConnect import winConnect
			from windows.winMain    import winMain
			from windows.winStarMap import winStarMap
			from windows.winMessage import winMessage
			from windows.winSystem  import winSystem
	
			sc_width = 1024
			sc_height = 768
	
			map_width = 600
			map_height = 500
	
			padding = 5
	
			middle = sc_width-map_width-padding
	
			self.connect = winConnect(app, -1, None)
			
			self.main    = winMain(app, -1, None, (0,0), (middle,50))
			self.message = winMessage(self.main, -1, None, (0,map_height-100), (middle,100))
			
			self.map     = winStarMap(self.main, -1, None, (middle+padding,0), (map_width-padding, map_height-padding*2))
			self.system  = winSystem(self.main, -1, None, (middle+padding,map_height), (map_width-padding, 200))

		def show(self):
			##########
			# Show the main window
			##########
			self.main.Show(TRUE)
			self.map.Show(TRUE)
			self.message.Show(TRUE)
			self.system.Show(TRUE)

		def hide(self):
			##########
			# Show the main window
			##########
			self.main.Show(FALSE)
			self.map.Show(FALSE)
			self.message.Show(FALSE)
			self.system.Show(FALSE)
	
	class appTP(wxApp):
		def OnInit(self):
			wxInitAllImageHandlers()

			self.windows = mainControl(self)
			self.connected = FALSE

			# If autoconnect
			if FALSE:
				try:
					self.Connect(host, username, password)
				except:
					# Pop-up a dialog saying connected failed.
					pass
			else:
				self.windows.connect.Show(TRUE)
			
			return TRUE
			
		def Connect(self, host, username, password):
			temp = string.split(host, ":", 1)

			if len(temp) == 1:
				self.host = host
				self.port = 6923
			else:
				self.host, self.port = temp
				self.port = int(self.port)
			
			self.socket = protocol.connect(self.host, self.port)
	
			if not self.socket:
				raise SocketError("Server is overloaded or busy! Please try again later.")

			self.username = username
			self.password = password

			l = protocol.Login(username=username, password=password)
			self.socket.send(str(l))
			r = protocol.readpacket(self.socket)

			pprint.pprint(l)
			pprint.pprint(str(l))
			pprint.pprint(r)
			pprint.pprint(str(r))

			if isinstance(r, protocol.Ok):
				self.connected = TRUE
				return TRUE
			elif isinstance(r, protocol.Fail):
				raise Exception("The username/password is bad")
			else:
				raise Exception("The server returned a bad response.")

		def Exit(self):
			sys.exit(1)


	app = appTP()
	app.MainLoop()
	
