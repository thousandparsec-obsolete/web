#! /usr/bin/env python

import math
import sys
import traceback

import config
from config import db, netlib

from sbases.Object import Object
from sbases.Order import Order

def WalkUniverse(top, order, callback, *args, **kw):
	"""\
	Walks around the universe and calls a command for each object.
	
	If the first argument is "before" parents will be called before there children.
	If the first argument is "after" parents will be called after there children.
	"""
	if order == "before":
		callback(top, *args, **kw)

	for id in top.contains():
		WalkUniverse(Object(id), order, callback, *args, **kw)

	if order == "after":
		callback(top, *args, **kw)

def OrderGet(top, d={}):
	"""
	Walks around the universe and puts the orders into the given dictionary.
	"""

	def o(obj, d=d):
		if obj.orders() > 0:
			# Find the first valid order on this object
			while True:
				order = Order(obj.id, 0)

				if False:
					order = None
				else:
					break

			if not d.has_key(order.type):
				d[order.type] = []

			d[order.type].append(order)

	WalkUniverse(top, "before", o)

def ReparentOne(obj):
	# Reparent the object
	parents = Object.bypos([obj.posx, obj.posy, obj.posz], size=0, orderby="size ASC")
	print "Possible parents", parents
	
	obj.parent = 0
	parents = [id for (id, time) in parents if Object(id).type != obj.type]
	if parents:
		obj.parent = parents[0]
	else:
		print "No parents left! Using Universe."
	
	print "New Parent", obj.parent


##def Reparent(top):
##	# FIXME: Borked
##	# FIXME: Cant walk the tree in this case as need to start from top every time.
##
##	c = []
##	def r(obj, c=c):
##		# FIXME: Reparent only objects which need reparenting
##		# Reparent the object
##		parents = Object.bypos([obj.posx, obj.posy, obj.posz], size=0, limit=2)
##		print "New object parents", parents
##		obj.parent = obj.id
##		while obj.parent == obj.id:
##			if len(parents) > 0:
##				id = parents.pop(-1).id
##				# Make sure we don't parent to the same type
##				if type(Object(id)) != type(obj):
##					obj.parent = id
##				continue
##			else:
##				obj.parent = 0
##		print "New object parent is", obj.parent
##		c.append(c)
##
##	WalkUniverse(top, c)
##	
##	for obj in c:
##		c.save()

def main():
	# Connect to the database
	db.begin()

	try:
		# Use the corret database
		db.query("USE %(database)s", database=sys.argv[1])
		
		# Clean up any phoney orders

		# Get all the orders
		d = {}
		OrderGet(Object(0), d)

		for type in [str(m.__name__) for m in config.order]:
			print type
			if type.startswith("sorders"):
				if not d.has_key(type):
					continue

				for order in d[type]:
					order.do()
		
			elif type.startswith("sactions"):
				__import__(type, globals(), locals(), ["do"]).do(Object(0))
		
		# Reparent the universe
		
	except:
		db.rollback()
		raise
	else:
		db.commit()
	
if __name__ == "__main__":
	main()


