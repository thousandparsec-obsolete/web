#! /usr/bin/env python

import copy
import pickle
import time

import config
from config import db, netlib

OK = netlib.objects.OK
Fail = netlib.objects.Fail
Sequence = netlib.objects.Sequence
constants = netlib.objects.constants

# Base objects
from sbases.SQL       import NoSuch
from sbases.Board     import Board
from sbases.Category  import Category
from sbases.Component import Component
from sbases.Design    import Design
from sbases.Message   import Message
from sbases.Object    import Object
from sbases.Order     import Order
from sbases.Property  import Property
from sbases.User      import User
from sbases.Resource  import Resource

class FullConnection(netlib.ServerConnection):

	def __init__(self, *args, **kw):
		netlib.ServerConnection.__init__(self, *args, **kw)
		self.user = None

	def check(self):
		if self.user == None:
			return False
		else:
			db.query("USE %(db)s", db=self.user.domain())
			db.query("COMMIT")
		return True

	def OnGetWithID(self, packet, type):
		"""\
		OnGetWithID(packet, type) -> [True | False]

		packet - Get packet to be processes, it must have the following
			packet.ids - The ids to be gotten
					
		type - The class used in processing, it must have the following
			type.realid(user, id)                - Get the real id for this object
			type(realid)                         - Creates the object
			typeinstance.allowed(user)           - Is the user allowed to see this object
			typeinstance.protect(user)           - Protect the object against this user
			typeinstance.to_packet(sequenceid)   - Creates a network packet with this sequence number
		"""
		if not self.check():
			return False

		print "Getting stuff with ids", packet.ids
		
		if len(packet.ids) > 1:
			self._send(Sequence(packet.sequence, len(packet.ids)))

		for id in packet.ids:
			try:
				# Get the real id of the object
				id = type.realid(self.user, id)
				
				o = type(id)

				# Is the user allowed to access this object?
				if not o.allowed(self.user):
					print "ERROR: No permission for %s with id %s." % (type, id)
					self._send(Fail(packet.sequence, constants.FAIL_NOSUCH, "No such %s." % type))
				else:
					# Protect certain details from a user (ie if can see only some of the object)
					o = o.protect(self.user)
					self._send(o.to_packet(packet.sequence))

			except NoSuch:
				print "ERROR: No such %s with id %s." % (type, id)
				self._send(Fail(packet.sequence, constants.FAIL_NOSUCH, "No such %s." % type))

		return True
	
	def OnGetID(self, packet, type):
		"""\
		OnGethID(packet, type) -> [True | False]

		packet - Get packet to be processes, it must have the following
			packet.key    - The last modified time
			packet.start  - Index to start from
			packet.amount - The number of items to get
					
		type - The class used in processing, it must have the following
			type.modified(user)                 - Get the latest modified time for that type (that this user can see)
			type.amount(user)                   - Get the number of this that exist (that this user can see)
			type.ids(user, start, amount)       - Get the ids (that this user can see)
			type.ids_packet()                   - Get the packet type for sending a list of ids
		"""
		if not self.check():
			return False

		print "Getting IDs with ", packet.key, packet.start, packet.amount

		key = type.modified(self.user)
		total = type.amount(self.user)
		
		if packet.key != -1 and key != packet.key:
			self._send(Fail(packet.sequence, constants.FAIL_NOSUCH, "Key is no longer valid, please get a new key." % (packet.start+packet.length, total)))
			return True
		
		if packet.start+packet.amount > total:
			print "Requested %s %s Actually %s." % (packet.start, packet.amount, total)
			self._send(Fail(packet.sequence, constants.FAIL_NOSUCH, "Requested to many IDs. (Requested %s, Actually %s." % (packet.start+packet.amount, total)))
			return True

		if packet.amount == -1:
			left = 0
		else:
			left = total - (packet.start+packet.amount)
		
		ids = type.ids(self.user, packet.start, packet.amount)
		self._send(type.id_packet()(packet.sequence, key, left, ids))

		return True
	
	def OnGetWithIDandSlot(self, packet, type, container):
		"""\
		OnGetWithIDandSlot(packet, type, container) -> [True | False]

		packet - Get packet to be processes, it must have the following
			packet.id		- The id of the container
			packet.slots	- The slots to be gotten
					
		type - The class used in processing, it must have the following
			type(realid, slot)                   - Creates the object
			typeinstance.allowed(user)           - Is the user allowed to see this object
			typeinstance.protect(user)           - Protect the object against this user
			typeinstance.to_packet(sequenceid)   - Creates a network packet with this sequence number

		container - The class that contains the other class
			container.realid(user, id)           - Get the real id for the container object
		"""
		if not self.check():
			return False
		
		# Get the real id
		id = container.realid(self.user, packet.id)
		
#		if len(packet.slots) > 1:
		self._send(Sequence(packet.sequence, len(packet.slots)))
		for slot in packet.slots:
			try:
				o = type(id, slot)

				# Is the user allowed to access this object?
				if not o.allowed(self.user):
					print "ERROR: No permission for %s with id %s." % (type, id)
					self._send(Fail(packet.sequence, constants.FAIL_NOSUCH, "No such %s." % type))
				else:
					# Protect certain details from a user (ie if can see only some of the object)
					o = o.protect(self.user)
					self._send(o.to_packet(packet.sequence))

			except NoSuch:
				print "ERROR: No such %s with id %s, %s." % (type, id, slot)
				self._send(Fail(packet.sequence, constants.FAIL_NOSUCH, "No such order."))

		return True

	def OnFeature_Get(self, p):
		self._send(netlib.objects.Feature(p.sequence, [ \
			constants.FEATURE_HTTP_THIS,
			constants.FEATURE_KEEPALIVE,
			constants.FEATURE_ORDERED_OBJECT,
			constants.FEATURE_ORDERED_ORDERDESC,
			constants.FEATURE_ORDERED_BOARD,
			constants.FEATURE_ORDERED_RESOURCE,
			constants.FEATURE_ORDERED_CATEGORY,
			constants.FEATURE_ORDERED_COMPONENT]))
		return True

	def OnLogin(self, packet):
		db.query("USE tp")

		# We need username and password
		pid = User.realid(packet.username, packet.password)
	
		if pid == -1:
			self._send(Fail(packet.sequence, constants.FAIL_NOSUCH, "Login incorrect or unknown username!"))
		else:
			self.user = User(id=pid)
			self._send(OK(packet.sequence, "Login Ok!"))
			
		return True

	def OnObject_GetById(self, packet):
		# FIXME: This should show the correct number of orders for a certain person
		return self.OnGetWithID(packet, Object)
		
	def OnObject_GetID(self, packet):
		return self.OnGetID(packet, Object)	

	def OnObject_GetID_ByPos(self, packet):
		if not self.check():
			return False

		objects = Object.bypos(packet.pos, packet.size)

		self._send(Sequence(packet.sequence, len(objects)))

		for object in objects:
			self._send(object.to_packet(packet.sequence))

	def OnObject_GetID_ByContainer(self, packet):
		if not self.check():
			return False
		
		objects = Object.byparent(packet.id)

#		self._send(Sequence(packet.sequence,)

	def OnOrderDesc_GetID(self, packet):
		if not self.check():
			return False

		# FIXME: There is a better place to put this class
		class OrderDesc:
			def modified(cls, user):
				return 0
			modified = classmethod(modified)
			
			def amount(cls, user):
				return len(Order.types.keys())
			amount = classmethod(amount)
			
			def ids(cls, user, start, amount):
				return [(id, 0) for id in Order.types.keys()[start:amount]]
			ids = classmethod(ids)
		
			def id_packet(cls):
				return netlib.objects.OrderDesc_IDSequence
			id_packet = classmethod(id_packet)

		return self.OnGetID(packet, OrderDesc)	

	def OnOrderDesc_Get(self, packet):
		if not self.check():
			return False

		self._send(Sequence(packet.sequence, len(packet.ids)))

		for id in packet.ids:
			try:
				self._send(Order.desc_packet(packet.sequence, id))
			except NoSuch:
				self._send(Fail(packet.sequence, constants.FAIL_NOSUCH, "No such order type."))

		return True

	def OnOrder_Get(self, packet):
		return self.OnGetWithIDandSlot(packet, Order, Object)

	def OnOrder_Insert(self, packet):
		if not self.check():
			return False

		try:
			order = Order(packet=packet)
			
			# Are we allowed to do this?
			if not order.object.allowed(self.user):
				self._send(Fail(packet.sequence, constants.FAIL_NOSUCH, "Permission denied."))
				print packet.id, packet.slot, "No Permission"
			else:	
				order.insert()
				self._send(OK(packet.sequence, "Order added."))
		except NoSuch:
			print packet.id, packet.slot, "Adding failed."
			self._send(Fail(packet.sequence, constants.FAIL_NOSUCH, "Order adding failed."))

		return True
	OnOrder = OnOrder_Insert

	def OnOrder_Remove(self, packet):
		if not self.check():
			return False

		self._send(Sequence(packet.sequence, len(packet.slots)))

		for slot in packet.slots:
			try:
				order = Order(packet.id, slot)
				
				# Are we allowed to do this?
				if not order.object.allowed(self.user):
					self._send(Fail(packet.sequence, constants.FAIL_NOSUCH, "No such order."))
					print self.user.id, packet.id, slot, "No Permission"
				else:	
					order.remove()
					self._send(OK(packet.sequence, "Order removed."))
			except NoSuch:
				print packet.id, slot, "No such order."
				self._send(Fail(packet.sequence, constants.FAIL_NOSUCH, "No such order."))

		return True

	def OnBoard_Get(self, packet):
		return self.OnGetWithID(packet, Board)
		
	def OnBoard_GetID(self, packet):
		return self.OnGetID(packet, Board)	
	
	def OnMessage_Get(self, packet):
		return self.OnGetWithIDandSlot(packet, Message, Board)

	def OnMessage_Insert(self, packet):
		if not self.check():
			return False

		try:
			# Mangle the board id
			packet.id = Board.realid(packet.id, self.user.id)

			message = Message(packet=packet)
			message.insert()
			self._send(OK(packet.sequence, "Message added."))
		except NoSuch:
			self._send(Fail(packet.sequence, constants.FAIL_NOSUCH, "Message adding failed."))

		return True

	OnMessage = OnMessage_Insert

	def OnMessage_Remove(self, packet):
		if not self.check():
			return False

		self._send(Sequence(packet.sequence, len(packet.slots)))

		for slot in packet.slots:
			try:
				message = Message(Board.realid(self.user, packet.id), slot)
				message.remove()
				self._send(OK(packet.sequence, "Message removed."))
			except NoSuch:
				self._send(Fail(packet.sequence, constants.FAIL_NOSUCH, "No such message."))

		return True

	def OnResource_Get(self, packet):
		return self.OnGetWithID(packet, Resource)
		
	def OnResource_GetID(self, packet):
		return self.OnGetID(packet, Resource)

	def OnCategory_Get(self, packet):
		return self.OnGetWithID(packet, Category)

	def OnCategory_GetID(self, packet):
		return self.OnGetID(packet, Category)

	def OnComponent_Get(self, packet):
		return self.OnGetWithID(packet, Component)

	def OnComponent_GetID(self, packet):
		return self.OnGetID(packet, Component)

	def OnDesign_Get(self, packet):
		return self.OnGetWithID(packet, Design)

	def OnDesign_GetID(self, packet):
		return self.OnGetID(packet, Design)

	def OnProperty_Get(self, packet):
		return self.OnGetWithID(packet, Property)

	def OnProperty_GetID(self, packet):
		return self.OnGetID(packet, Property)

	def _send(self, packet):
		time.sleep(config.lag/1000.0)
		return netlib.ServerConnection._send(self, packet)

class FullServer(netlib.Server):
	handler = FullConnection
	debug = False

	def __init__(self, host, port="6923"):
		netlib.Server.__init__(self, host, port)

	def endofturn(self, sig, frame):
		packet = netlib.objects.TimeRemaining(0, 0)
		for connection in self.connections:
			connection._send(packet)

def main():
	port = 6923
	while True:
		try:
			s = FullServer("", port=port)
			print "Used port", port
		except:
			print "This port in use...", port
			port += 1
			continue
		try:
			import signal

			signal.signal(signal.SIGUSR1, s.endofturn)
		except ImportError:
			pass

		# Import all the order_desc from the database
		Order.load_all()
		for key, value in  netlib.objects.OrderDescs().items():
			print key, value
			print value.names

		s.serve_forever()

if __name__ == "__main__":
	main()

