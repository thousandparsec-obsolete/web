"""Let's define a personalized SchemeError exception that will be
thrown if bad things happen."""

__license__ = "MIT License"

class SchemeError(Exception): pass
